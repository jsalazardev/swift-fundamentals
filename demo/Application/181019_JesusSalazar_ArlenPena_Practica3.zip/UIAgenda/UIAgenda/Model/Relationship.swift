//
//  Relationship.swift
//  UIAgenda
//
//  Created by jesus on 10/18/18.
//  Copyright © 2018 jesus. All rights reserved.
//

import Foundation

enum Relationship: String {
    case Grandma = "Grandma"
    case Grandad = "Grandad"
    case Friend = "Friend"
    case Brother = "Brother"
    case Sister = "Sister"
    case Son = "Son"
    case Daughter = "Daughter"
    case Mother = "Mother"
    case Pather = "Pather"
    case Other = "Otro"
    
}
