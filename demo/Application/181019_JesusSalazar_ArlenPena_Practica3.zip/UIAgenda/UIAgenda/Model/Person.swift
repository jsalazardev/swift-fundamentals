//
//  Person.swift
//  UIAgenda
//
//  Created by jesus on 10/18/18.
//  Copyright © 2018 jesus. All rights reserved.
//

import Foundation

class Person: DataGeneric{
    //Parameters
    var contacts = [Contact]()
    var events = [Event]()
    
    //Construct
    override init(id: Int, birthday: String, firstName: String, lastName: String, address: String, mail: String){
        super.init(id: id, birthday: birthday, firstName: firstName, lastName: lastName, address: address, mail: mail)
    }
    
    init(id: Int, birthday: String, firstName: String, lastName: String, address: String, mail: String, contacts: [Contact], events: [Event]){
        self.contacts = contacts
        self.events = events
        super.init(id: id, birthday: birthday, firstName: firstName, lastName: lastName, address: address, mail: mail)
    }
    
    //Functions
    override func toString() -> String {
        var data:String = ""
        data.append("[Person \n\t")
        data.append(super.toString())
        data.append(self.getContactString())
        data.append(self.getEventString())
        return data
    }
    
    func getContactString() -> String {
        var data = ""
        var cont: Int = 0
        
        data.append("\n[Contacts] \n")
        for contact in self.contacts {
            data.append("\t")
            data.append(contentsOf: String(cont + 1))
            data.append(contentsOf: "  ")
            data.append(contact.toString())
            data.append(cont+1 != contacts.count ? "\n" : "")
            cont += 1
        }
        return data
    }
    
    func getEventString() -> String {
        var data = ""
        var cont: Int = 0
        
        data.append("\n[Events] \n")
        for contact in self.events {
            data.append("\t")
            data.append(contentsOf: String(cont + 1))
            data.append(contentsOf: "  ")
            data.append(contact.toString() + "\n")
            cont += 1
        }
        return data
    }
    
    func getFullName() -> String {
        return "\(self.firstName) \(self.lastName)"
    }
}
