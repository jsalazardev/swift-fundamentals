//
//  Event.swift
//  UIAgenda
//
//  Created by jesus on 10/18/18.
//  Copyright © 2018 jesus. All rights reserved.
//

import Foundation

class Event{
    //Parameters
    var id : Int
    var place: String
    var eventDate: String
    var name: String
    var contacts = [Contact]()
    
    var dataColumn = ["Lugar", "Fecha", "Nombre"]
    
    //Construct
    init(id: Int, place: String, eventDate: String, name: String) {
        self.id = id
        self.place = place
        self.eventDate = eventDate
        self.name = name
    }
    
    init(id: Int, place: String, eventDate: String, name: String, contacts: [Contact]) {
        self.id = id
        self.place = place
        self.eventDate = eventDate
        self.name = name
        self.contacts = contacts
    }
    
    //Functions
    func toString() -> String {
        var data:String = ""
        data.append(contentsOf: self.place)
        data.append(contentsOf: ", ")
        data.append(contentsOf: self.eventDate)
        data.append(contentsOf: ", ")
        data.append(contentsOf: self.name)
        data.append(self.getContactString())
        return data
    }
    
    func getContactString() -> String {
        var data = ""
        var cont: Int = 0
        
        data.append("\n\t[Contacts - Event]\n")
        for contact in self.contacts {
            data.append("\t\t")
            data.append(contentsOf: String(cont + 1))
            data.append(contentsOf: "  ")
            data.append(contact.toString())
            data.append(cont+1 != contacts.count ? "\n" : "")
            cont += 1
        }
        return data
    }
    
    func toValue(position: Int) -> String{
        var value: String
        switch position {
        case 0:
            value = self.place
        case 1:
            value = self.eventDate
        case 2:
            value = self.name
        default:
            value = ""
        }
        return value
    }
}
