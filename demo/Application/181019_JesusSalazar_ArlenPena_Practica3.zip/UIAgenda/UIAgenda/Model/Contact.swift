//
//  Contact.swift
//  UIAgenda
//
//  Created by jesus on 10/18/18.
//  Copyright © 2018 jesus. All rights reserved.
//

import Foundation

class Contact: DataGeneric{
    //Parameters
    var business: String
    var relationship: String
    
    //Construct
    init(id: Int, birthday: String, firstName: String, lastName: String, address: String, mail: String, business: String, relationship: String){
        self.business = business
        self.relationship = relationship
        super.init(id: id, birthday: birthday, firstName: firstName, lastName: lastName, address: address, mail: mail)
    }
    
    //Functions
    override func toString() -> String {
        var data:String = ""
        data.append(super.toString())
        data.append(contentsOf: ", ")
        data.append(contentsOf: self.business )
        data.append(contentsOf: ", ")
        data.append(contentsOf: self.relationship)
        return data
    }
}
