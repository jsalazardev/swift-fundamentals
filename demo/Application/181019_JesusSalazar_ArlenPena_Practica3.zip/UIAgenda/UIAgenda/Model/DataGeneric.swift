//
//  DataGeneric.swift
//  UIAgenda
//
//  Created by jesus on 10/18/18.
//  Copyright © 2018 jesus. All rights reserved.
//

import Foundation

class DataGeneric{
    //Parameters
    var id: Int
    var birthday: String
    var firstName: String
    var lastName: String
    var address: String
    var mail : String
    
    var dataColumn = ["Nombre", "Apellido", "Direccion", "Mail", "Fecha Nacimiento", "Edad"]
    
    //Construct
    init(id: Int, birthday: String, firstName: String, lastName: String, address: String, mail: String) {
        self.id = id
        self.birthday = birthday
        self.firstName = firstName
        self.lastName = lastName
        self.address = address
        self.mail = mail
    }
    
    //Functions
    func getAge() -> Int{
        var age : Int = 0;
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "dd/MM/yyyy"
        let date = dateFormat.date(from: self.birthday)
        age = Calendar.current.dateComponents([.year], from: date!, to: Date()).year!
        return age
    }
    
    func toString() -> String {
        var data:String = ""
        data.append(contentsOf: self.firstName + " " + self.lastName)
        data.append(contentsOf: ", ")
        data.append(contentsOf: String(getAge()))
        data.append(contentsOf: " year, ")
        data.append(contentsOf: self.address)
        data.append(contentsOf: ", ")
        data.append(contentsOf: self.mail)
        return data
    }
    
    func toValue(position: Int) -> String{
        var value: String
        switch position {
        case 0:
            value = self.firstName
        case 1:
            value = self.lastName
        case 2:
            value = self.address
        case 3:
            value = self.mail
        case 4:
            value = self.birthday
        case 5:
            value = "\(getAge()) Años"
        default:
            value = ""
        }
        return value
    }
}
