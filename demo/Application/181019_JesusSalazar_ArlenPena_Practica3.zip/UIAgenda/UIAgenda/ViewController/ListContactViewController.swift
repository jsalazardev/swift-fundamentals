//
//  ListContactViewController.swift
//  UIAgenda
//
//  Created by jesus on 10/19/18.
//  Copyright © 2018 jesus. All rights reserved.
//

import UIKit

class ListContactViewController: UIViewController,
UITableViewDataSource, UITableViewDelegate {
    
    var person: Person! = nil
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Contacto \(section + 1)"
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return person!.contacts.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return person!.dataColumn.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.value1, reuseIdentifier: "celda")
        let row = indexPath.row
        let section = indexPath.section
        cell.textLabel?.text = person!.dataColumn[row]
        cell.detailTextLabel?.text = person!.contacts[section].toValue(position: row)
        return cell
    }
    
    //table
    @IBOutlet weak var tblContacts: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblContacts.dataSource = self
        self.tblContacts.delegate = self
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
