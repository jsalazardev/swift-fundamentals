//
//  ViewController.swift
//  UIAgenda
//
//  Created by jesus on 10/18/18.
//  Copyright © 2018 jesus. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
    //Globals
    var person: Person! = nil
    //Outlet
    @IBOutlet weak var lName: UILabel!
    @IBOutlet weak var lAge: UILabel!
    @IBAction func btnUpdate(_ sender: Any) {
        initDataSource()
        updateData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "seguePersonInfo"){
            let personInfoVC = segue.destination as! PersonInfoViewController
            personInfoVC.person = person
        }
        if(segue.identifier == "segueListContact"){
            let listContactVC = segue.destination as! ListContactViewController
            listContactVC.person = person
        }
        if(segue.identifier == "segueListEvent"){
            let listEventVC = segue.destination as! ListEventViewController
            listEventVC.person = person
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initDataSource()
        updateData()
    }
    
    func initDataSource(){
        let dataSource: DataSource = DataSource()
        person = dataSource.getPerson()
        print(person!.toString())
    }
    
    @objc func updateData(){
        if let objPerson = person {
            lName.text = objPerson.getFullName()
            lAge.text = "\(objPerson.getAge()) Años"
        }
    }
}

