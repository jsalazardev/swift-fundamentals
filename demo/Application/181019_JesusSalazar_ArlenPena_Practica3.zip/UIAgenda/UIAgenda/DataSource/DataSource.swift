//
//  DataSource.swift
//  UIAgenda
//
//  Created by jesus on 10/18/18.
//  Copyright © 2018 jesus. All rights reserved.
//

import Foundation

class DataSource{
    
    let contacts: [Contact] = [
        Contact.init(id: 10, birthday: "19/01/1977", firstName: "Nadia", lastName: "Jimenez", address : "Av. Los Sauces", mail : "nadia@bancomer.com", business: "Bancomer", relationship: Relationship.Friend.rawValue),
        Contact.init(id: 12, birthday: "20/05/1990", firstName: "Luis", lastName: "Perez", address : "Reforma # 24", mail : "luis@gmail.com", business: "Banco Azteca", relationship: Relationship.Other.rawValue),
        Contact.init(id: 15, birthday: "12/02/1980", firstName: "Jose", lastName: "Aguilar", address : "Av. Siempre Viva", mail : "jose@bancomer.com", business: "Bancomer", relationship: Relationship.Friend.rawValue),
        Contact.init(id: 20, birthday: "01/01/1965", firstName: "Guillermo", lastName: "Jimenez", address : "Av. Vicente Guerrero #43", mail : "guille@banamex", business: "Banamex", relationship: Relationship.Grandad.rawValue),
        Contact.init(id: 30, birthday: "01/02/1968", firstName: "Luisa", lastName: "Villavicencio", address : "Simulacro #21", mail : "luisa@ejemplares", business: "Los ejemplares", relationship: Relationship.Mother.rawValue),
        Contact.init(id: 19, birthday: "01/02/1968", firstName: "Roberto", lastName: "Lopez", address : "Los Sauces #21", mail :   "robert@ejemplares", business: "Los Cielos", relationship: Relationship.Other.rawValue),
        Contact.init(id: 21, birthday: "01/01/1938", firstName: "Juan", lastName: "Alberto", address : "Villa #21", mail :   "jesus@ejemplares", business: "Los ejemplares", relationship: Relationship.Son.rawValue),
        Contact.init(id: 1, birthday: "01/02/1948", firstName: "Hugo", lastName: "Carlos", address : "Simulacro #21", mail :   "hugo@ejemplares", business: "Los ejemplares", relationship: Relationship.Son.rawValue),
        Contact.init(id: 7, birthday: "01/02/1968", firstName: "Karla", lastName: "Barranco", address : "Simulacro #21", mail :   "karla@ejemplares", business: "Los ejemplares", relationship: Relationship.Sister.rawValue),
        Contact.init(id: 23, birthday: "19/09/1997", firstName: "Fernanda", lastName: "Mercado", address : "Av. Los Sauces", mail : "fernanda@bancomer.com", business: "Santander", relationship: Relationship.Friend.rawValue),
        Contact.init(id: 24, birthday: "20/05/1990", firstName: "Luis", lastName: "Perez", address : "Reforma # 24", mail : "luis@gmail.com", business: "Banco Azteca", relationship: Relationship.Pather.rawValue),
        Contact.init(id: 25, birthday: "12/02/1980", firstName: "Jose", lastName: "Aguilar", address : "Av. Siempre Viva", mail : "jose@bancomer.com", business: "Bancomer", relationship: Relationship.Friend.rawValue),
        Contact.init(id: 29, birthday: "01/01/1984", firstName: "Gabriel", lastName: "Ruiz", address : "Av. Alberto Guerrero #43", mail : "guille@banamex", business: "Banamex", relationship: Relationship.Grandad.rawValue),
        Contact.init(id: 32, birthday: "01/06/1978", firstName: "Ximena", lastName: "Cantu", address : "Simulacro #189", mail : "Xmen@ejemplares", business: "Los ejemplares", relationship: Relationship.Other.rawValue)
    ]
    
    let events: [Event] = [
        Event.init(id: 100, place: "Salon Jardin", eventDate: "27/11/2018", name: "Cumple Susy"),
        Event.init(id: 101, place: "Restaurant Alce", eventDate: "01/09/2018", name: "Comida Negocios"),
        Event.init(id: 102, place: "Jardin La Villita", eventDate: "30/12/2018", name: "Fin de anio"),
        Event.init(id: 103, place: "La terraza", eventDate: "15/11/2018", name: "Las amigas"),
        Event.init(id: 104, place: "Ofician Juan", eventDate: "27/11/2018", name: "Acotacion de contratos"),
        Event.init(id: 105, place: "Oficina Torres GS", eventDate: "17/11/2018", name: "Revision de prioridades"),
        Event.init(id: 106, place: "Sala de junta A", eventDate: "27/11/2018", name: "Nuevos Proyectos"),
        Event.init(id: 107, place: "Restaurante Italiano", eventDate: "17/11/2018", name: "Comida Provedores"),
        
    ]
    
    let persons: [Person] = [
        Person.init(id: 50, birthday: "27/06/1992", firstName: "Cecilia", lastName: "Jimenez", address : "Colinas de Alvarado", mail : "cecilia@outlook.com.mx"),
        Person.init(id: 51, birthday: "06/01/1972", firstName: "Jesus", lastName: "Salazar", address : "Av. Benito Juarez # 2", mail : "jesalazar@upax.com.mx"),
        Person.init(id: 52, birthday: "13/07/1982", firstName: "Fernanda", lastName: "Mendez", address : "Av. Miguel Hidalgo", mail : "ferMen@upax.com.mx"),
    ]
    
    init() {
        
    }
    
    func getPerson() -> Person {
        let numRandom = Int.random(in: 0 ..< self.persons.count)
        let person = persons[numRandom]
        person.contacts = getContacts()
        person.events = getEvents()
        return person
    }
    
    func getContacts() -> [Contact] {
        let numRandom = Int.random(in: 1 ..< self.contacts.count)
        var listContact = [Contact]()
        var listContactReg = [Int]()
        var cont = 1
        while cont < numRandom {
            var numContact:Int
            repeat{
                numContact = Int.random(in: 0 ..< numRandom - 1)
            } while listContactReg.contains(numContact)
            listContactReg.append(numContact)
            listContact.append(self.contacts[numContact])
            cont += 1
        }
        return listContact
    }
    
    func getEvents() -> [Event] {
        let numRandom = Int.random(in: 1 ..< self.events.count)
        var listEvent = [Event]()
        var listEventReg = [Int]()
        var cont = 1
        while cont < numRandom {
            var numEvent:Int
            repeat{
                numEvent = Int.random(in: 0 ..< numRandom - 1)
            } while listEventReg.contains(numEvent)
            listEventReg.append(numEvent)
            let event = self.events[numEvent]
            event.contacts = getContacts()
            listEvent.append(event)
            cont += 1
        }
        return listEvent
    }
    
    func getPersonIndex(id :Int) -> Int{
        var indexP: Int = 0
        var cont: Int = 0
        for person in self.persons {
            if(person.id == id){
                indexP = cont
            }
            cont += 1
        }
        return indexP;
    }
}
