//
//  ViewController.swift
//  LoginRegister
//
//  Created by jesus on 10/17/18.
//  Copyright © 2018 jesus. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lError: UILabel!
    @IBOutlet weak var tfNombre: UITextField!
    @IBOutlet weak var tfTelefono: UITextField!
    @IBOutlet weak var tfMail: UITextField!
    @IBOutlet weak var tfContrasena: UITextField!
    @IBOutlet weak var tfRevisaContrasena: UITextField!
    @IBOutlet weak var tfFechaNacimiento: UITextField!
    @IBOutlet weak var sSexo: UISwitch!
    
    @IBAction func bRegister(_ sender: UIButton) {
        validateData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        lError.isHidden = true;
    }

    @objc func validateData(){
        var msg = ""
        if tfNombre.text != "" {
            succesIinput(element: tfNombre)
            if tfMail.text != "" {
                succesIinput(element: tfMail)
                if tfContrasena.text != "" {
                    succesIinput(element: tfContrasena)
                    if tfRevisaContrasena.text != "" {
                        succesIinput(element: tfRevisaContrasena)
                        if tfFechaNacimiento.text != "" {
                            succesIinput(element: tfFechaNacimiento)
                        }else{
                            errorIinput(element: tfFechaNacimiento)
                            msg = "La fecha de nacimiento es requerida"
                        }
                    }else{
                        errorIinput(element: tfRevisaContrasena)
                        msg = "La confirmacion de contrasena es requerida"
                    }
                }else{
                    errorIinput(element: tfContrasena)
                    msg = "La contrasena es requerida"
                }
            }else{
                errorIinput(element: tfMail)
                msg = "El correo electronico es requerido"
            }
        }else{
            errorIinput(element: tfNombre)
            msg = "El nombre es requerido"
        }
        lError.text = msg
    }
    
    @objc func succesIinput(element: UITextField) -> Void{
        lError.isHidden = true;
        element.layer.borderWidth = 0
    }
    @objc func errorIinput(element: UITextField) -> Void{
        let erroColor = UIColor.red
        lError.isHidden = false;
        element.layer.borderWidth = 1.0
        element.layer.borderColor = erroColor.cgColor
    }

}

